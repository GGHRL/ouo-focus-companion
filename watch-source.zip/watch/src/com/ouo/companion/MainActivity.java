package com.ouo.companion;
import android.app.Activity;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity implements SensorEventListener {
  private WebView web;
  private SensorManager sensors;
  private Sensor motion;
  private boolean pageReady=false,gravityReady=false;
  private final float[] gravity=new float[3];
  private long previousSample=0,lastMotionMs=0;
  private final ShakeDetector shakes=new ShakeDetector();
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().setFlags(1024,1024);
    getWindow().getDecorView().setSystemUiVisibility(5894|1024|512);
    sensors=(SensorManager)getSystemService(SENSOR_SERVICE);
    if(sensors!=null){motion=sensors.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);if(motion==null)motion=sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);}
    try {
      web=new WebView(this);
      web.setBackgroundColor(Color.BLACK);
      web.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
      WebSettings settings=web.getSettings();
      settings.setJavaScriptEnabled(true);
      settings.setDomStorageEnabled(true);
      settings.setAllowFileAccess(true);
      settings.setSupportZoom(false);
      settings.setBuiltInZoomControls(false);
      web.setWebViewClient(new WebViewClient(){
        @Override public void onPageStarted(WebView view,String url,android.graphics.Bitmap icon){pageReady=false;}
        @Override public void onPageFinished(WebView view,String url){pageReady=true;}
      });
      web.setWebChromeClient(new WebChromeClient());
      setContentView(web);
      web.loadUrl("file:///android_asset/index.html");
    } catch (RuntimeException ex) {
      new AlertDialog.Builder(this).setTitle("无法打开 OuO")
        .setMessage("手表上的网页组件不可用，请检查系统或网页组件更新。")
        .setPositiveButton("关闭",(d,w)->finish()).show();
    }
  }
  @Override protected void onResume(){super.onResume();shakes.reset();gravityReady=false;previousSample=0;lastMotionMs=0;if(sensors!=null&&motion!=null)sensors.registerListener(this,motion,SensorManager.SENSOR_DELAY_GAME);}
  @Override protected void onPause(){if(sensors!=null)sensors.unregisterListener(this);shakes.reset();if(web!=null&&pageReady)web.evaluateJavascript("window.ouoWatchMotion && window.ouoWatchMotion(0,0)",null);super.onPause();}
  @Override public void onAccuracyChanged(Sensor sensor,int accuracy){}
  @Override public void onSensorChanged(SensorEvent event){
    if(!pageReady||web==null)return;
    float x=event.values[0],y=event.values[1],z=event.values[2];
    if(event.sensor.getType()==Sensor.TYPE_ACCELEROMETER){
      if(!gravityReady){gravity[0]=x;gravity[1]=y;gravity[2]=z;gravityReady=true;previousSample=event.timestamp;return;}
      float dt=Math.min(.2f,Math.max(.001f,(event.timestamp-previousSample)/1000000000f));previousSample=event.timestamp;
      float alpha=.45f/(.45f+dt);
      gravity[0]=alpha*gravity[0]+(1-alpha)*x;gravity[1]=alpha*gravity[1]+(1-alpha)*y;gravity[2]=alpha*gravity[2]+(1-alpha)*z;
      x-=gravity[0];y-=gravity[1];z-=gravity[2];
    }
    long ms=event.timestamp/1000000L;
    if(ms-lastMotionMs>=34){
      lastMotionMs=ms;
      float screenX=x,screenY=-y;
      int rotation=getWindowManager().getDefaultDisplay().getRotation();
      if(rotation==1){screenX=-y;screenY=-x;}else if(rotation==2){screenX=-x;screenY=y;}else if(rotation==3){screenX=y;screenY=x;}
      screenX=Math.max(-30f,Math.min(30f,screenX));screenY=Math.max(-30f,Math.min(30f,screenY));
      web.evaluateJavascript("window.ouoWatchMotion && window.ouoWatchMotion("+Float.toString(screenX)+","+Float.toString(screenY)+")",null);
    }
    if(shakes.sample(event.timestamp/1000000L,x,y,z))web.evaluateJavascript("window.ouoWatchShake && window.ouoWatchShake()",null);
  }
  @Override public void onBackPressed(){ if(web!=null)web.loadUrl("file:///android_asset/index.html"); else super.onBackPressed(); }
  @Override protected void onDestroy(){if(sensors!=null)sensors.unregisterListener(this);if(web!=null){web.destroy();web=null;}super.onDestroy();}
}
