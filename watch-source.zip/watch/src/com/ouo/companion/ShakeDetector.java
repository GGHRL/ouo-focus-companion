package com.ouo.companion;
/** Three moderate changing-direction impulses within 2.5 seconds; independent of Android for trace testing. */
final class ShakeDetector {
  private long lastImpulse=-1,started=-1,cooldownUntil=0;
  private int count=0;
  private float px,py,pz;
  void reset(){count=0;lastImpulse=-1;started=-1;}
  boolean sample(long ms,float x,float y,float z){
    if(ms<cooldownUntil)return false;
    float magnitude=(float)Math.sqrt(x*x+y*y+z*z);
    if(magnitude<5.5f)return false;
    if(lastImpulse>=0&&ms-lastImpulse<120)return false;
    if(lastImpulse<0||ms-lastImpulse>1000||ms-started>2500){count=1;started=ms;}
    else {float dot=(x*px+y*py+z*pz)/magnitude;if(dot>.25f)return false;count++;}
    px=x/magnitude;py=y/magnitude;pz=z/magnitude;lastImpulse=ms;
    if(count>=3){reset();cooldownUntil=ms+3500;return true;}
    return false;
  }
}
